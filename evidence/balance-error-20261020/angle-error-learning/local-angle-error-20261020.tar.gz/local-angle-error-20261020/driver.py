from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from hashlib import sha256
import json, os, shutil, subprocess, time
from pathlib import Path
from cartpole_sdk.learning.error_training import load_profile,source_identity
ROOT=Path('/Users/rbafna/projects/cartpole_v2');OUT=ROOT/'runs/local-angle-error-20261020'
PROFILE=ROOT/'training/profiles/rl-encoder-20261020';ACTOR=ROOT/'training/candidates/balance-20261020/actor.json'
def digest(p):return sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
OUT.mkdir(exist_ok=False);(OUT/'logs').mkdir();shutil.copy2(__file__,OUT/'driver.py')
exp,inputs=load_profile(PROFILE,observer_bw=8,seconds=5.)
pins=source_identity();actor_hash=digest(ACTOR)
commands=[]
for seed in (3,17):
 for bias in (0,1):
  name=f'bias{bias}-seed{seed}'
  argv=[str(ROOT/'.venv/bin/python'),'-m','cartpole_sdk.learning.error_training','train','--profile',str(PROFILE),
    '--output',str(OUT/name),'--observer-bw','8','--seed',str(seed),'--bias-degrees',str(bias),'--steps','4096','--every','4096',
    '--seconds','5','--evaluation-seconds','10','--evaluation-seeds','66000','66001','--learning-rate','.000003','--policy-std','.02','--imitation-updates','1500']
  commands.append(dict(name=name,argv=argv))
write(OUT/'protocol.json',dict(schema='cartpole-angle-error-pilot-20261020-v1',declared_at_utc=datetime.now(timezone.utc).isoformat(),
 status='DEVELOPMENT_ONLY',hardware_accepted=False,export_actor=False,source=pins,input_files=inputs,experiment=exp,
 optimizer_seeds=[3,17],bias_amplitudes_degrees=[0,1],training_seeds=list(range(13000,13128)),evaluation_seeds=[66000,66001],
 evaluation_role='Fresh development poses, explicitly inspected at initial/final checkpoints; no heldout-selection reuse.',
 bias_matrix_degrees=[0,-.5,.5,-1,1],training_steps_per_run=4096,total_training_decisions=16384,
 expected_evaluation_decisions=80000,teacher_updates_per_run=1500,teacher_gains=[1,2,40,2],
 purpose='Matched plumbing and short exploratory learning comparison; not convergence, full swing-up or deployment qualification.',
 commands=commands,driver_sha256=digest(OUT/'driver.py'),preserved_actor_sha256=actor_hash,concurrency=2,threads_per_worker=1))
env=dict(os.environ,PYTHONPATH=str(ROOT/'src'),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
 MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONUNBUFFERED='1')
def worker(item):
 began=time.monotonic();print(json.dumps(dict(event='started',name=item['name'])),flush=True)
 with (OUT/'logs'/f"{item['name']}.log").open('x') as stream:
  result=subprocess.run(item['argv'],cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
 receipt=dict(item,returncode=result.returncode,wall_seconds=time.monotonic()-began)
 write(OUT/'logs'/f"{item['name']}.receipt.json",receipt);print(json.dumps(dict(event='finished',**receipt)),flush=True)
 return receipt
with ThreadPoolExecutor(max_workers=2) as pool:receipts=[f.result() for f in as_completed([pool.submit(worker,item) for item in commands])]
if any(r['returncode'] for r in receipts):raise RuntimeError('failed trial; retain receipts and incomplete artifacts')
assert source_identity()==pins and digest(ACTOR)==actor_hash
assert all(digest(Path(p))==v for p,v in inputs.items())
reports={item['name']:json.loads((OUT/item['name']/'report.json').read_text()) for item in commands}
summary=[];decisions=0;evaluations=0
for name,r in reports.items():
 folder=OUT/name;recipe=json.loads((folder/'recipe.json').read_text())
 assert r['completed'] and r['provenance']==pins and r['experiment']==exp
 assert digest(folder/'recipe.json')==r['recipe_sha256'] and digest(folder/'source.zip')==r['source_zip_sha256']
 assert all(r.get(k)==v for k,v in recipe.items())
 assert [e['steps'] for e in r['evaluations']]==[0,4096]
 for evaluation in r['evaluations']:
  assert digest(folder/evaluation['checkpoint'])==evaluation['checkpoint_sha256']
  evaluations+=sum(e['proposed_decisions'] for e in evaluation['episodes'])
 decisions+=r['evaluations'][-1]['steps']
 summary.append(dict(name=name,seed=r['optimizer_seed'],bias_degrees=r['actor_input_bias']['amplitude_degrees'],
  initial=r['evaluations'][0]['summary'],final=r['evaluations'][-1]['summary'],
  recipe_sha256=r['recipe_sha256'],final_checkpoint_sha256=r['evaluations'][-1]['checkpoint_sha256']))
for seed in (3,17):
 a,b=(reports[f'bias{bias}-seed{seed}']['evaluations'][0] for bias in (0,1))
 assert a['policy_weights_sha256']==b['policy_weights_sha256'] and a['summary']==b['summary']
write(OUT/'summary.json',dict(completed=True,hardware_accepted=False,export_actor=False,protocol_sha256=digest(OUT/'protocol.json'),
 source_and_input_pins_unchanged=True,prior_actor_sha256_unchanged=actor_hash,matched_initial_weights_and_metrics=True,
 training_decisions=decisions,evaluation_proposed_decisions=evaluations,teacher_supervised_updates=6000,runs=summary,receipts=receipts))
print(json.dumps(dict(event='pilot_completed',training_decisions=decisions,evaluation_decisions=evaluations)),flush=True)
