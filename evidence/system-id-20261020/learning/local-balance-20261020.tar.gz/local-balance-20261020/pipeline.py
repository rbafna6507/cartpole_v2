"""Frozen local orchestration for the authorized October 20 matched experiment."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/Users/rbafna/projects/cartpole_v2')
OUT = ROOT/'runs/local-balance-20261020'
PROFILE = ROOT/'training/profiles/rl-encoder-20261020'
GAINS = ROOT/'evidence/rl-balance-20261018/teacher-gains.json'
PYTHON = ROOT/'.venv/bin/python'
SEEDS = (3, 17, 29)
ENV = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
           VECLIB_MAXIMUM_THREADS='1', NUMEXPR_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1',
           PYTHONUNBUFFERED='1')


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def file_hash(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def announce(**row):
    print(json.dumps(dict(time=datetime.now(timezone.utc).isoformat(), **row)), flush=True)


def run_jobs(jobs, stage):
    def worker(name, command):
        began = time.monotonic()
        announce(stage=stage, run=name, event='started')
        with (OUT/'logs'/f'{name}.log').open('x') as stream:
            completed = subprocess.run(command, cwd=ROOT, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
        result = dict(name=name, command=list(map(str,command)), returncode=completed.returncode,
                      wall_seconds=time.monotonic()-began)
        write(OUT/'logs'/f'{name}.receipt.json', result)
        announce(stage=stage, run=name, event='finished', returncode=completed.returncode,
                 wall_seconds=result['wall_seconds'])
        return result
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(worker,name,command) for name,command in jobs]
        results = [future.result() for future in as_completed(futures)]
    if any(row['returncode'] for row in results):
        raise RuntimeError(f'{stage} failed; all receipts and failed run outputs retained')
    return results


def validate_run(path, source):
    from cartpole_sdk.learning.balance_experiment import source_identity
    from cartpole_sdk.learning.ppo import experiment_identity
    recipe = json.loads((path/'recipe.json').read_text())
    report = json.loads((path/'report.json').read_text())
    if not report['completed'] or recipe['provenance'] != source or source_identity() != source:
        raise ValueError('incomplete trial or changed training provenance')
    if (file_hash(path/'recipe.json') != report['recipe_sha256'] or
            file_hash(path/'source.zip') != report['source_zip_sha256'] or
            any(report.get(k) != v for k,v in recipe.items()) or
            experiment_identity(recipe['experiment']) != recipe['experiment_sha256']):
        raise ValueError('trial recipe/source/experiment binding mismatch')
    if [e['steps'] for e in report['evaluations']] != list(range(0,20481,4096)):
        raise ValueError('unexpected saved checkpoint accounting')
    for evaluation in report['evaluations']:
        if file_hash(path/evaluation['checkpoint']) != evaluation['checkpoint_sha256']:
            raise ValueError('checkpoint digest mismatch')
    return recipe, report


def metrics(evaluation):
    rows = evaluation['episodes']
    traces = [point for row in rows for point in row.get('trajectory',[])]
    return dict(episodes=len(rows), holds=sum(row['hold_success'] for row in rows),
        faults=sum(row['fault_reason'] is not None for row in rows),
        complete_episodes=sum(row['steps'] == round(evaluation['seconds']*100) for row in rows),
        balanced_samples=sum(abs(t['theta'])<.15 and abs(t['omega'])<1 and abs(t['x'])<.12 for t in traces),
        samples=len(traces), worst_max_abs_x_m=max(row['max_abs_x_m'] for row in rows),
        mean_tail_x_rms_m=sum(row['tail_x_rms_m'] for row in rows)/len(rows),
        mean_tail_theta_rms_rad=sum(row['tail_theta_rms_rad'] for row in rows)/len(rows),
        max_abs_raw_m_s2=max((abs(t['raw']) for t in traces),default=None),
        minimum_balanced_fraction=min(row['balanced_fraction'] for row in rows))


def full_balance(m, count):
    return (m['episodes'] == m['holds'] == m['complete_episodes'] == count and m['faults'] == 0 and
            m['samples'] > 0 and m['balanced_samples'] == m['samples'] and m['minimum_balanced_fraction'] == 1.)


def main():
    from cartpole_sdk.learning.balance_experiment import source_identity
    from cartpole_sdk.learning.model_experiment import build_experiment
    began = time.monotonic()
    OUT.mkdir(parents=True, exist_ok=False)
    (OUT/'logs').mkdir()
    shutil.copy2(__file__, OUT/'pipeline.py')
    shutil.copytree(PROFILE, OUT/'frozen-profile')
    shutil.copy2(GAINS, OUT/'teacher-gains.json')
    source = source_identity()
    profile_pins = {str(p.relative_to(ROOT)):file_hash(p) for p in sorted(PROFILE.glob('*.json'))}
    values = {name:json.loads((PROFILE/f'{name}.json').read_text()) for name in
              ('executor-parameters','observation-config','prior-parameters')}
    experiment = build_experiment(PROFILE/'model.json', executor_parameters=values['executor-parameters'],
        observation_config=values['observation-config'], prior_parameters=values['prior-parameters'],
        development_only=True, seconds=5.)
    if values['executor-parameters']['bw'] != 10 or values['executor-parameters']['rail'] != .309000015:
        raise ValueError('profile does not match requested current readback')
    protocol = dict(schema='cartpole-id-balance-protocol-20261020-v1',
        written_at_utc=datetime.now(timezone.utc).isoformat(), status='DEVELOPMENT_ONLY', hardware_accepted=False,
        profile=str(PROFILE), profile_sha256=profile_pins, source=source,
        pipeline_sha256=file_hash(OUT/'pipeline.py'), teacher_gains_sha256=file_hash(GAINS), experiment=experiment,
        optimizer_seeds=list(SEEDS), initializations=['teacher','scratch'], steps_per_run=20480, every=4096,
        total_training_decisions=122880, total_development_evaluation_decisions=72000,
        total_paired_heldout_evaluation_decisions=288000, total_parity_decisions=24000,
        training_seeds=list(range(12000,12128)), development_seeds=[61000,61001],
        training_seconds=5, development_seconds=10, learning_rate=3e-6, policy_std=.02,
        constraint='equilibrium', teacher_imitation_updates=1500,
        prior_information='Teacher has extra supervised compute and controller knowledge; equal online budgets only.',
        training_randomization=None, concurrency=2, threads_per_worker=1,
        selection=dict(candidates='All final 20480-decision teacher checkpoints; never intermediate checkpoints or scratch.',
            development_gate='Both complete 10-second upright poses, no fault, final hold, and every sampled state balanced.',
            ranking=['smallest worst transient max_abs_x_m', 'smallest mean tail_x_rms_m', 'smallest optimizer seed'],
            frozen_before='Any paired heldout results are inspected.',
            heldout_gate='Selected final must complete all eight 60-second upright episodes fault-free with every sampled state balanced.',
            failure_rule='No heldout-based candidate substitution; preserve all results and report failure.'),
        heldout=dict(seeds=list(range(62000,62008)), seconds=60, starts=['upright'],
                     checkpoints=[0,20480], runs='all three teacher seeds', role='Paired post-selection evaluation; never tuning data.'),
        parity=dict(seeds=[63000,63001], seconds=60, starts=['upright','hanging'],
            gate='Emission error <=1e-5 m/s², no rejected input; both numeric upright episodes fully balanced. Hanging is a separate untrained task, not a balance acceptance criterion.'),
        limitations=['Nominal simulation, assumed actuator authority; no measured uncertainty randomization.',
                     'Expected calibration count is not physical vertical certification.',
                     'No hardware access, deployment approval, fallback controller or acceptance-bit changes.'])
    write(OUT/'protocol.json',protocol)
    announce(event='protocol_frozen',path=str(OUT/'protocol.json'),sha256=file_hash(OUT/'protocol.json'))
    jobs=[]
    for seed in SEEDS:
        for arm in ('teacher','scratch'):
            name=f'{arm}-seed{seed}'
            command=[str(PYTHON),str(ROOT/'examples/balance_learning.py'),'train','--profile',str(PROFILE),
                '--output',str(OUT/name),'--initialization',arm,'--seed',str(seed),'--steps','20480',
                '--every','4096','--seconds','5','--evaluation-seconds','10','--evaluation-seeds','61000','61001',
                '--constraint','equilibrium','--learning-rate','.000003','--policy-std','.02','--imitation-updates','1500']
            if arm=='teacher':command+=['--gains',str(GAINS)]
            jobs.append((name,command))
    train_receipts=run_jobs(jobs,'training')
    summaries=[];eligible=[]
    for seed in SEEDS:
        for arm in ('teacher','scratch'):
            name=f'{arm}-seed{seed}'; recipe,report=validate_run(OUT/name,source)
            row=dict(run=name, seed=seed, initialization=arm, final=metrics(report['evaluations'][-1]),
                     initial=metrics(report['evaluations'][0]), recipe_sha256=file_hash(OUT/name/'recipe.json'),
                     final_checkpoint_sha256=report['evaluations'][-1]['checkpoint_sha256'])
            summaries.append(row)
            if arm=='teacher' and full_balance(row['final'],2):eligible.append(row)
    write(OUT/'development-summary.json',dict(runs=summaries, receipts=train_receipts, hardware_accepted=False))
    eligible.sort(key=lambda r:(r['final']['worst_max_abs_x_m'],r['final']['mean_tail_x_rms_m'],r['seed']))
    selected=eligible[0] if eligible else None
    write(OUT/'selection.json',dict(protocol_sha256=file_hash(OUT/'protocol.json'),selected=selected,
          eligible_ranked=[r['run'] for r in eligible], selection_basis='Development only, prior to heldout evaluation.', hardware_accepted=False))
    announce(event='selection_frozen',selected=None if selected is None else selected['run'])
    jobs=[]
    for seed in SEEDS:
        for checkpoint in (0,20480):
            name=f'heldout-teacher-seed{seed}-step{checkpoint}'
            command=[str(PYTHON),str(ROOT/'examples/balance_learning.py'),'evaluate',str(OUT/f'teacher-seed{seed}'),
                '--output',str(OUT/name),'--seeds',*map(str,range(62000,62008)),
                '--seconds','60','--checkpoint',str(checkpoint),'--starts','upright']
            jobs.append((name,command))
    heldout_receipts=run_jobs(jobs,'paired-heldout')
    heldout=[]
    for seed in SEEDS:
        for checkpoint in (0,20480):
            name=f'heldout-teacher-seed{seed}-step{checkpoint}'
            evaluation=json.loads((OUT/name/'evaluation.json').read_text())
            heldout.append(dict(run=f'teacher-seed{seed}', checkpoint=checkpoint, directory=name,
                                evaluation_sha256=file_hash(OUT/name/'evaluation.json'),metrics=metrics(evaluation)))
    write(OUT/'heldout-summary.json',dict(runs=heldout,receipts=heldout_receipts,hardware_accepted=False))
    if selected is None:
        raise RuntimeError('No teacher final qualified on development; no selected actor exported.')
    selected_heldout=next(r for r in heldout if r['run']==selected['run'] and r['checkpoint']==20480)
    if not full_balance(selected_heldout['metrics'],8):
        raise RuntimeError('Preselected teacher failed the heldout gate; no candidate substitution or selected export.')
    import torch
    from stable_baselines3 import PPO
    from cartpole_sdk.learning.candidate_parity import check_candidate
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    recipe,report=validate_run(OUT/selected['run'],source)
    final=report['evaluations'][-1];checkpoint=OUT/selected['run']/final['checkpoint']
    announce(event='sdk_parity_started',selected=selected['run'])
    model=PPO.load(checkpoint,device='cpu')
    parity=check_candidate(model,recipe['experiment'],OUT/'selected-sdk-parity',
        checkpoint_sha256=final['checkpoint_sha256'],seeds=(63000,63001),seconds=60.)
    if file_hash(checkpoint)!=final['checkpoint_sha256']:
        raise ValueError('checkpoint changed during numeric export')
    upright=[]
    for row in parity['episodes']:
        if row['start']!='upright':continue
        trace=OUT/'selected-sdk-parity'/row['trace_path']; count=balanced=0
        for line in trace.open():
            p=json.loads(line)['ground_truth_after'];count+=1
            balanced+=abs(p['theta'])<.15 and abs(p['omega'])<1 and abs(p['x'])<.12
        upright.append(dict(seed=row['seed'],samples=count,balanced_samples=balanced,
                            complete=row['full_horizon_complete'],hold=row['hold_success']))
    parity_task_pass=all(r['samples']==r['balanced_samples']==6000 and r['complete'] and r['hold'] for r in upright) and len(upright)==2
    if source_identity()!=source or any(file_hash(ROOT/p)!=pin for p,pin in profile_pins.items()):
        raise ValueError('Frozen profile/source changed during experiment')
    final_report=dict(schema='cartpole-id-balance-result-20261020-v1',completed=True,
        status='DEVELOPMENT_ONLY',hardware_accepted=False,simulation_only=True,
        protocol_sha256=file_hash(OUT/'protocol.json'),selected=selected,heldout=selected_heldout,
        numeric_actor=str(OUT/'selected-sdk-parity/actor.json'),
        actor_sha256=file_hash(OUT/'selected-sdk-parity/actor.json'),
        parity_report_sha256=file_hash(OUT/'selected-sdk-parity/report.json'),
        emission_parity_pass=parity['emission_parity_pass'],numeric_upright_full_balance_pass=parity_task_pass,
        numeric_upright=upright,wall_seconds=time.monotonic()-began,
        qualification='Nominal simulation only; bounded hardware development still requires separate live admission.')
    write(OUT/'result.json',final_report)
    announce(event='completed',selected=selected['run'],emission_parity=parity['emission_parity_pass'],
             numeric_upright_full_balance=parity_task_pass,wall_seconds=final_report['wall_seconds'])
    if not parity['emission_parity_pass'] or not parity_task_pass:
        raise RuntimeError('Selected numeric actor failed export/task gate; diagnostic artifact retained, no promotion.')


if __name__=='__main__':
    try:
        main()
    except BaseException as error:
        announce(event='pipeline_failed',error=type(error).__name__,detail=str(error))
        if OUT.exists() and not (OUT/'failure.json').exists():
            write(OUT/'failure.json',dict(error=type(error).__name__,detail=str(error),hardware_accepted=False))
        raise
