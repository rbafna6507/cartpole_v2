"""Post-candidate teacher diagnostic only; no optimizer, export, or selection."""
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json, math
from pathlib import Path
import time
import numpy as np
from cartpole_sdk.learning import transfer_checks as tc
from cartpole_sdk.learning.ppo import TrainingEnv

ROOT=Path('/Users/rbafna/projects/cartpole_v2')
OUT=ROOT/'runs/local-balance-20261020'
DEST=OUT/'teacher-centering-diagnostic'

def digest(p):return sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')

class Teacher:
 def __init__(self,gains):self.gains=gains
 def predict(self,observation,deterministic=True):
  x,v,s,c,w,_,_=observation['state']
  raw=np.dot(self.gains,[x,v,math.atan2(s,c),w])
  return np.array([max(-25.,min(25.,float(raw)))/25.]),None

def main():
 exp=deepcopy(json.loads((OUT/'protocol.json').read_text())['experiment'])
 exp['simulation_config']['max_steps']=1000
 names=['position_gain','velocity_gain','theta_gain','omega_gain']
 gains=[(1,2,40,2),(4,4,40,2),(4,6,40,2),(8,4,40,2),(8,6,40,2)]
 candidates=[dict(name='_'.join(map(str,g)),gains=dict(zip(names,g))) for g in gains]
 scenarios=[s for s in tc.scenarios(exp) if s['name'] in ('nominal','angle-minus1deg','angle-plus1deg')]
 source=tc.source_identity();actor=OUT/'selected-sdk-parity/actor.json';actor_hash=digest(actor)
 config=exp['simulation_config'];L=config['effective_length_m'];I=.75*config['pole_mass_kg']*L*L
 local_d=config['hinge_damping']/I+config['hinge_coulomb_friction_nm']/(I*config['hinge_friction_velocity_scale_rad_s'])
 for candidate,coeff in zip(candidates,gains):
  candidate['ideal_static_abs_x_for_one_degree_m']=math.radians(1)*coeff[2]/coeff[0]
  candidate['approximate_continuous_eigenvalues_max_real']={}
  for d in (0.,8.,local_d):
   A=np.array([[0.,1,0,0],[0,0,0,0],[0,0,0,1],[0,0,9.81/L,-d]])
   B=np.array([0,1,0,-1/L])[:,None]
   candidate['approximate_continuous_eigenvalues_max_real'][str(d)]=float(np.max(np.linalg.eigvals(A+B@np.array([coeff])).real))
 DEST.mkdir(exist_ok=False);(DEST/'traces').mkdir()
 write(DEST/'protocol.json',dict(schema='cartpole-teacher-centering-diagnostic-v1',declared_at_utc=datetime.now(timezone.utc).isoformat(),
  status='DEVELOPMENT_ONLY',hardware_accepted=False,simulation_only=True,role='New exploratory development diagnostic after candidate selection; no reused heldout seeds, optimizer, retraining, candidate replacement or deployment export.',
  runner_sha256=digest(Path(__file__)),parent_protocol_sha256=digest(OUT/'protocol.json'),source=source,experiment=exp,
  selected_actor_sha256=actor_hash,seeds=[65000,65001],seconds=10,starts=['upright'],candidates=candidates,scenarios=scenarios,
  formula='clip(kx*x + kv*v + ktheta*atan2(sin(theta),cos(theta)) + komega*omega, -25,25)',
  analytic_scope='Static relation assumes true vertical, zero velocity/rate, zero raw acceleration and no saturation. Approximate continuous linearization omits delay/jerk/quantization; each variant is stable for damping0 and8 but stronger centering may lose small-velocity stability at the smooth friction derivative. Simulation retains complete nominal physics and sensing.'))
 began=time.monotonic();episodes=[]
 for candidate,coeff in zip(candidates,gains):
  local=DEST/candidate['name'];local.mkdir();(local/'traces').mkdir()
  model=Teacher(coeff)
  for scenario in scenarios:
   env=TrainingEnv(exp,[65000,65001])
   try:
    for seed in (65000,65001):
     row=tc._episode(model,env,seed=seed,start='upright',scenario=scenario,root=local)
     row['candidate']=candidate['name'];row['trace_path']=candidate['name']+'/'+row['trace_path'];episodes.append(row)
   finally:env.close()
  print(json.dumps(dict(candidate=candidate['name'],completed=len(episodes))),flush=True)
 assert source==tc.source_identity() and actor_hash==digest(actor)
 summary=[]
 for candidate in candidates:
  for scenario in scenarios:
   group=[e for e in episodes if e['candidate']==candidate['name'] and e['scenario']==scenario['name']]
   summary.append(dict(candidate=candidate['name'],scenario=scenario['name'],episodes=len(group),holds=sum(e['hold_success'] for e in group),
    continuous_full_balance=sum(e['balanced_fraction']==1. for e in group),faults=sum(e['fault_reason'] is not None for e in group),
    max_abs_x_m=max(e['max_abs_x_m'] for e in group),mean_tail_x_rms_m=float(np.mean([e['final_window_x_rms_m'] for e in group]))))
 write(DEST/'report.json',dict(completed=True,status='DEVELOPMENT_ONLY',hardware_accepted=False,deployable=False,protocol_sha256=digest(DEST/'protocol.json'),
  selected_actor_sha256_before=actor_hash,selected_actor_sha256_after=digest(actor),source_unchanged=True,episodes=episodes,summary=summary,
  proposed_decisions=sum(sum(1 for _ in (DEST/e['trace_path']).open()) for e in episodes),advanced_decisions=sum(e['steps'] for e in episodes),wall_seconds=time.monotonic()-began))
 print(json.dumps(dict(completed=True,episodes=len(episodes),wall_seconds=time.monotonic()-began)),flush=True)
if __name__=='__main__':main()
