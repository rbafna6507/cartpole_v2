from hashlib import sha256
import importlib.util, json, statistics
from pathlib import Path
ROOT=Path('/Users/rbafna/projects/cartpole_v2');OUT=ROOT/'runs/local-balance-20261020'
spec=importlib.util.spec_from_file_location('frozen_balance_pipeline',OUT/'pipeline.py');pipeline=importlib.util.module_from_spec(spec);spec.loader.exec_module(pipeline)
load=lambda p:json.loads(p.read_text())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
protocol=load(OUT/'protocol.json');result=load(OUT/'result.json');stress=load(OUT/'selected-stress/report.json');parity=load(OUT/'selected-sdk-parity/report.json')
assert digest(OUT/'pipeline.py')==protocol['pipeline_sha256']
assert all(digest(ROOT/p)==v for p,v in protocol['profile_sha256'].items())
assert all(digest(OUT/'frozen-profile'/Path(p).name)==v for p,v in protocol['profile_sha256'].items())
assert digest(OUT/'teacher-gains.json')==protocol['teacher_gains_sha256']
training=development=0
for seed in protocol['optimizer_seeds']:
 for arm in protocol['initializations']:
  recipe,report=pipeline.validate_run(OUT/f'{arm}-seed{seed}',protocol['source'])
  training+=report['evaluations'][-1]['steps']
  development+=sum(len(e['trajectory']) for checkpoint in report['evaluations'] for e in checkpoint['episodes'])
heldout_steps=0;paired=[]
for seed in protocol['optimizer_seeds']:
 pair=[load(OUT/f'heldout-teacher-seed{seed}-step{s}/evaluation.json') for s in (0,20480)]
 a,b=({e['seed']:e for e in ev['episodes']} for ev in pair)
 assert sorted(a)==sorted(b)==protocol['heldout']['seeds']
 heldout_steps+=sum(len(e['trajectory']) for ev in pair for e in ev['episodes'])
 deltas=[b[s]['tail_x_rms_m']-a[s]['tail_x_rms_m'] for s in sorted(a)]
 m=[pipeline.metrics(e) for e in pair]
 paired.append(dict(optimizer_seed=seed,episodes=8,initial=m[0],final=m[1],
  mean_paired_rms_delta_m=statistics.mean(deltas),paired_rms_improvements=sum(d<0 for d in deltas),
  paired_rms_regressions=sum(d>0 for d in deltas),
  initial_continuously_balanced_episodes=sum(all(abs(t['theta'])<.15 and abs(t['omega'])<1 and abs(t['x'])<.12 for t in e['trajectory']) for e in pair[0]['episodes']),
  final_continuously_balanced_episodes=sum(all(abs(t['theta'])<.15 and abs(t['omega'])<1 and abs(t['x'])<.12 for t in e['trajectory']) for e in pair[1]['episodes'])))
actor=OUT/'selected-sdk-parity/actor.json'
assert digest(actor)==result['actor_sha256']==parity['actor_file_sha256']==load(OUT/'stress-summary.json')['actor_sha256_after']
for parent,report in ((OUT/'selected-sdk-parity',parity),(OUT/'selected-stress',stress)):
 assert report['completed'] and report['hardware_accepted'] is False and report['deployable'] is False
 assert digest(parent/'recipe.json')==report['recipe_sha256']
 for episode in report['episodes']:
  assert digest(parent/episode['trace_path'])==episode['trace_sha256']
  trace_rows=[json.loads(line) for line in (parent/episode['trace_path']).open()]
  assert sum(row['physical_time_advanced'] for row in trace_rows)==episode['steps']
upright=[e for e in stress['episodes'] if e['start']=='upright' and e['expected']=='task_success']
hanging=[e for e in stress['episodes'] if e['start']=='hanging' and e['expected']=='task_success']
fault=[e for e in stress['episodes'] if e['expected']=='fault_response']
counts=dict(training=training,development=development,paired_heldout=heldout_steps,numeric_parity=parity['compared_actions'],stress_advanced=sum(e['steps'] for e in stress['episodes']),stress_proposed=sum(sum(1 for _ in (OUT/'selected-stress'/e['trace_path']).open()) for e in stress['episodes']))
analysis=dict(schema='cartpole-balance-final-audit-20261020-v1',completed=True,status='DEVELOPMENT_ONLY',hardware_accepted=False,robust=False,
 counted_decisions=counts,teacher_extra_supervised_updates=4500,
 pinned_training_source_and_profiles_unchanged=True,all_trial_checkpoint_recipe_source_and_evaluation_trace_bindings_valid=True,
 actor_sha256=digest(actor),selected_run=result['selected']['run'],paired_teacher_heldout=paired,
 learning_interpretation='Teacher prior explains initial balance success. Scratch final0/6 versus teacher final6/6 on equal online-budget development poses, with extra teacher supervision. Heldout RMS improved12/24 paired poses and regressed12/24. Selected seed mean improves0.220mm, with4/8 paired wins and essentially unchanged worst excursion. This is not evidence of a reliable PPO improvement.',
 stress=dict(episodes=len(stress['episodes']),upright_task_holds=sum(e['hold_success'] for e in upright),upright_task_episodes=len(upright),
  hanging_task_holds=sum(e['hold_success'] for e in hanging),hanging_task_episodes=len(hanging),
  expected_fault_passes=sum(e['fault_response_pass'] for e in fault),expected_fault_episodes=len(fault),
  angle_bias_upright_holds=sum(e['hold_success'] for e in upright if e['scenario'].startswith('angle-')),
  angle_bias_upright_episodes=sum(e['scenario'].startswith('angle-') for e in upright),scenario_gate_pass=stress['scenario_gate_pass']),
 profile_interpretation='Updated executor bw10 and rail .309000015; original passive dynamics coefficients retained. No new accepted physical fit.',
 limitations=['One-degree angle bias in either direction breaks all four upright stress trials; candidate is not robust.',
 'stress-summary.actual_decisions counts36012 physical-advanced decisions; trace audit counts36016 proposed decisions including four invalid-input decisions with no time advance.',
 'Stress uses trained predictor through TrainingEnv; actual numeric SDK parity is a separate fresh-seed report.',
 'Balance wrapper is narrower than generic evaluation; default raw cap .25m/s² can reject nominal demands.',
 'Physical host command lease expiry remains unresolved; cyclic GC deferral is not a demonstrated complete fix.',
 'No hardware was accessed by this agent.'],
 artifact_hashes={str(p.relative_to(OUT)):digest(p) for p in (OUT/'protocol.json',OUT/'selection.json',OUT/'result.json',OUT/'selected-sdk-parity/report.json',OUT/'selected-stress/report.json',OUT/'deployment-envelope-check.json')})
with (OUT/'final-audit.json').open('x') as stream:json.dump(analysis,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
print(json.dumps(dict(completed=True,counts=counts,stress=analysis['stress'],actor_sha256=digest(actor)),sort_keys=True))
