from hashlib import sha256
import json, math
from pathlib import Path
from cartpole_sdk.learning.balance_hardware import START_LIMITS, RUN_LIMITS, _load_policy
OUT=Path('/Users/rbafna/projects/cartpole_v2/runs/local-balance-20261020')
PARITY=OUT/'selected-sdk-parity'
actor=PARITY/'actor.json'
policy=_load_policy(actor)
report=json.loads((PARITY/'report.json').read_text())
rows=[]
keys=('position_m','velocity_m_s','angle_rad','angular_rate_rad_s')
for episode in report['episodes']:
 if episode['start']!='upright': continue
 trace=PARITY/episode['trace_path']
 assert sha256(trace.read_bytes()).hexdigest()==episode['trace_sha256']
 data=[json.loads(s) for s in trace.read_text().splitlines()]
 values=[]
 for row in data:
  s=row['encoded_observation']['state']
  values.append((s[0],s[1],math.atan2(s[2],s[3]),s[4],s[6]))
 first=values[0]
 start_pass=all(abs(first[i])<=START_LIMITS[k] for i,k in enumerate(keys)) and first[4]==0
 limits=dict(RUN_LIMITS,position_m=policy.position_limit)
 violations=[row['decision_index'] for row,v in zip(data,values) if any(abs(v[i])>=limits[k] for i,k in enumerate(keys)) or v[4]!=0]
 rows.append(dict(seed=episode['seed'],samples=len(data),start_pass=start_pass,
  first_observation=dict(zip(keys+('brake_direction',),first)),
  maxima={k:max(abs(v[i]) for v in values) for i,k in enumerate(keys+('brake_direction',))},
  runtime_boundary_violations=violations,
  max_abs_raw_action_m_s2=max(abs(r['sdk_raw_action_m_s2']) for r in data),
  trace_path=episode['trace_path'],trace_sha256=episode['trace_sha256']))
heldout=json.loads((OUT/'heldout-teacher-seed17-step20480/evaluation.json').read_text())
result=dict(schema='cartpole-balance-observed-envelope-check-v1',hardware_accepted=False,
 actor_file_sha256=sha256(actor.read_bytes()).hexdigest(),boundary_sha256=sha256(Path('/Users/rbafna/projects/cartpole_v2/src/cartpole_sdk/learning/balance_hardware.py').read_bytes()).hexdigest(),
 parity_report_sha256=sha256((PARITY/'report.json').read_bytes()).hexdigest(),
 start_limits=START_LIMITS,run_limits=dict(RUN_LIMITS,position_m=policy.position_limit),
 episodes=rows,all_sampled_starts_and_observed_envelopes_pass=all(r['start_pass'] and not r['runtime_boundary_violations'] for r in rows),
 heldout_truth_peak_speed_m_s=max(abs(s['v']) for ep in heldout['episodes'] for s in ep['trajectory']),
 limitations=['Replay inspection of two nominal simulation observation traces, not a balance-wrapper end-to-end run or hardware qualification.',
 'Eight heldout reports preserve truth speed only, so no commanded-speed claim is made for them.',
 'Default .25 m/s² demand cap intentionally rejects many nominal actor demands; no ceiling or guard was changed.',
 'Hardware command lease expiry remains unresolved. Cyclic GC deferral is a mitigation, not a demonstrated fix.'])
with (OUT/'deployment-envelope-check.json').open('x') as stream:
 json.dump(result,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
print(json.dumps(result,sort_keys=True))
