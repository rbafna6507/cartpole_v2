"""Append the explicitly requested fixed stress screen without changing the actor."""
from datetime import datetime, timezone
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys
import time

OUT = Path(__file__).resolve().parent


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def main():
    import torch
    from stable_baselines3 import PPO
    from cartpole_sdk.learning import transfer_checks
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    spec = importlib.util.spec_from_file_location('frozen_balance_pipeline', OUT/'pipeline.py')
    pipeline = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pipeline)
    base = json.loads((OUT/'protocol.json').read_text())
    selection = json.loads((OUT/'selection.json').read_text())['selected']
    recipe, report = pipeline.validate_run(OUT/selection['run'], base['source'])
    final = report['evaluations'][-1]
    checkpoint = OUT/selection['run']/final['checkpoint']
    if sys.argv[1:] == ['--prepare']:
        protocol = dict(schema='cartpole-balance-additional-stress-20261020-v1',
            declared_at_utc=datetime.now(timezone.utc).isoformat(),
            parent_protocol_sha256=digest(OUT/'protocol.json'), selection_sha256=digest(OUT/'selection.json'),
            selected_run=selection['run'], checkpoint_sha256=final['checkpoint_sha256'],
            selected_recipe_sha256=digest(OUT/selection['run']/'recipe.json'),
            selected_source_zip_sha256=digest(OUT/selection['run']/'source.zip'),
            runner_sha256=digest(__file__), evaluation_source=transfer_checks.source_identity(),
            seeds=[64000,64001], seconds=10, scenarios='All 11 unchanged transfer_checks scenarios.',
            starts=['upright','hanging'], expected_episodes=44, hardware_accepted=False,
            role='Additional engineering sensitivity screen requested after development selection; never training, reselection, or actor modification.',
            interpretation='Report every failure, especially either sign of one-degree angle bias. Preserve the nominally qualified development actor even when stress fails; no robustness or hardware acceptance claim.')
        write(OUT/'stress-protocol.json',protocol)
        print(json.dumps(dict(event='stress_protocol_frozen',sha256=digest(OUT/'stress-protocol.json'))),flush=True)
        return
    if sys.argv[1:]:raise ValueError('use no argument to run or --prepare to declare')
    protocol=json.loads((OUT/'stress-protocol.json').read_text())
    result=json.loads((OUT/'result.json').read_text())
    if (not result['completed'] or not result['emission_parity_pass'] or
            not result['numeric_upright_full_balance_pass'] or
            digest(__file__)!=protocol['runner_sha256'] or
            digest(checkpoint)!=protocol['checkpoint_sha256'] or
            digest(OUT/'selection.json')!=protocol['selection_sha256'] or
            transfer_checks.source_identity()!=protocol['evaluation_source']):
        raise ValueError('selected candidate/parity or frozen stress inputs failed validation')
    actor=OUT/'selected-sdk-parity/actor.json'
    actor_before=digest(actor)
    began=time.monotonic()
    model=PPO.load(checkpoint,device='cpu')
    stress=transfer_checks.run_suite(model,recipe['experiment'],OUT/'selected-stress',
        seeds=tuple(protocol['seeds']),seconds=protocol['seconds'],checkpoint_sha256=protocol['checkpoint_sha256'],
        source_binding=dict(protocol_sha256=digest(OUT/'stress-protocol.json'),
            selected_run=selection['run'],selected_recipe_sha256=protocol['selected_recipe_sha256'],
            selected_source_zip_sha256=protocol['selected_source_zip_sha256'],
            parent_protocol_sha256=protocol['parent_protocol_sha256'],
            evaluation_source=protocol['evaluation_source']))
    if digest(actor)!=actor_before or digest(checkpoint)!=protocol['checkpoint_sha256']:
        raise ValueError('actor/checkpoint changed during stress screen')
    write(OUT/'stress-summary.json',dict(completed=True,hardware_accepted=False,
        status='DEVELOPMENT_ONLY',actor_sha256_before=actor_before,actor_sha256_after=digest(actor),
        scenario_gate_pass=stress['scenario_gate_pass'],episodes=len(stress['episodes']),
        actual_decisions=sum(r['steps'] for r in stress['episodes']),summary=stress['summary'],
        wall_seconds=time.monotonic()-began,report_sha256=digest(OUT/'selected-stress/report.json'),
        interpretation=protocol['interpretation']))
    print(json.dumps(dict(event='stress_completed',episodes=len(stress['episodes']),
        scenario_gate_pass=stress['scenario_gate_pass'],wall_seconds=time.monotonic()-began)),flush=True)


if __name__=='__main__':main()
