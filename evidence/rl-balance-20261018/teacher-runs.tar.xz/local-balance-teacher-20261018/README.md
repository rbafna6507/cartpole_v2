# Observed-state nominal balance teacher search

**Selected law:** `raw = clip(1*x + 2*v + 40*theta + 2*omega, -25, 25)` in m/s²; wrap observed theta with `atan2(sin(theta), cos(theta))`. The inputs come only from the returned Gym observation. `raw_acceleration` in `examples/balance_teacher_search.py` implements the callable law. Simulator truth is accessed only after acting, for metrics.

The selected teacher holds all six 25-second development episodes with every step meeting `|x|<.12 m`, `|theta|<.15 rad`, and `|omega|<1 rad/s`. The source and all trajectories are hash pinned. This is local nominal balance evidence only.

| Controller | Final 5s holds | Min balanced fraction | Peak abs(x) (mm) | Worst margin (mm) | Mean cart RMS (mm) | Worst final5s cart swing (mm) | Mean raw RMS | Mean raw Δ RMS | Faults |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Original host teacher | 6/6 | 0.9892 | 125.30 | -5.30 | 80.52 | 236.09 | 0.4830 | 0.0424 | 0 |
| Intermediate 6,5,30,3 | 6/6 | 1.0000 | 83.54 | 36.46 | 54.95 | 163.91 | 0.4059 | 0.0563 | 0 |
| Selected 1,2,40,2 | 6/6 | 1.0000 | 72.50 | 47.50 | 14.51 | 9.68 | 0.1087 | 0.0686 | 0 |

All candidates retain the original 100 Hz decisions, 1 ms physics, encoder noise/quantization and causal rate observer, 3 ms telemetry delay, 1 ms command delay, one motion governor with jerk 150 m/s³, and raw acceleration bounds ±25 m/s². No dynamics randomization is applied. No hardware or Colab connection is made.

## Selection and model reasoning

1. Fifteen candidates, including the exact host teacher, its memoryless linear equivalent, hand gains and five discrete LQR designs, were screened on seeds 42000/42001 for 15 seconds each. Host and linear-prior trajectories agreed. The intermediate `(6,5,30,3)` teacher reduced the cart cycle but did not remove it. Aggressive ideal LQR designs failed in the complete observed/governed simulation.
2. Ten additional four-gain hypotheses targeted local stability of the smooth hinge friction. The zero-rate friction derivative is included in the approximate acceleration-input linearization. The original and intermediate gains have unstable complex eigenvalues in this local approximation; `(1,2,40,2)` has a stable slow pair near `-0.3324 ± 0.7379i`. Finite-velocity friction, rate-estimator lag and the governor are nonlinear or omitted from synthesis, so the full environment remains the empirical criterion.
3. The original host, intermediate `(6,5,30,3)` and selected `(1,2,40,2)` teachers were each evaluated for 25 seconds on seeds 42000–42005. These are development/regression cases after inspection. Seeds 45000+ were never used.

The selected law substantially reduces cart motion and total raw acceleration RMS. Its raw action step-to-step RMS is higher because the larger raw angle gain amplifies encoder quantization/noise; the action-change tradeoff is retained in the table and plots. It remains subject to the unchanged governor.

## Artifacts

- `teacher-gains.json`: selected formula, exact gains, development status and provenance links.
- `settling-gains-flat.json`: flat four-gain dictionary for the parent learning harness.
- `screen/`, `refine/`, `confirmation/`: immutable recipes, complete per-candidate episode metrics, JSONL trajectories, source ZIPs and selected-gain artifacts.
- `comparison.png`: complete cart trajectories, final-five-second motion, representative pole/raw action traces, and per-seed RMS metrics.
- `verification.json`: checked recipe/source/trajectory digests and approximate closed-loop eigenvalues.

## Reproduction

From the same repository and installed dependencies (versions pinned in each recipe), run with a new output directory. The script sets the numerical thread environment and PyTorch threads to one.

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python examples/balance_teacher_search.py --output runs/NEW-screen --seconds 15 --seeds 42000 42001
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python examples/balance_teacher_search.py --output runs/NEW-refine --seconds 15 --seeds 42000 42001 --candidates runs/local-balance-teacher-20261018/refine-candidates.json
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python examples/balance_teacher_search.py --output runs/NEW-confirmation --seconds 25 --seeds 42000 42001 42002 42003 42004 42005 --candidates runs/local-balance-teacher-20261018/confirmation-candidates.json
```

Source commit at run start: `254615c8161af21b1ccdd557e1808aa971f363a8`. Search script SHA-256: `d0c64765acaf2233be953936fb27e613a42e5e548cd7c8ddbd753224c67438cb`. Confirmation source ZIP SHA-256: `978277c37d708449d8896c2916b5d01e49606bb0fc9122c3838c84b725f45a5c`. Source archives, not the commit alone, capture the exact uncommitted runtime state.

No stochastic optimization, neural training, swing-up assessment, dynamics/timing variation, invalid-sensor stress, physical qualification, production parameter change, or export is claimed here.
