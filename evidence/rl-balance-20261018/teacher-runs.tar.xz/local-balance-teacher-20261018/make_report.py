"""Recreate the teacher comparison report/plots from frozen experiment outputs."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
reports={name:json.loads((BASE/name/'report.json').read_text()) for name in ('screen','refine','confirmation')}
assert all(report['completed'] for report in reports.values())
verification=[]
for phase,report in reports.items():
    folder=BASE/phase
    recipe=json.loads((folder/'recipe.json').read_text())
    assert sha256((folder/'recipe.json').read_bytes()).hexdigest()==report['recipe_sha256']
    assert sha256((folder/'source.zip').read_bytes()).hexdigest()==recipe['source_zip_sha256']
    with zipfile.ZipFile(folder/'source.zip') as archive:
        for name,digest in recipe['source_manifest'].items():
            assert sha256(archive.read(name)).hexdigest()==digest,(phase,name)
    for candidate in report['candidates']:
        for episode in candidate['episodes']:
            path=folder/episode['trajectory_path']
            assert sha256(path.read_bytes()).hexdigest()==episode['trajectory_sha256']
            assert episode['steps']==len(path.read_text().splitlines())
    verification.append(dict(phase=phase,recipe_sha256=report['recipe_sha256'],
        report_sha256=sha256((folder/'report.json').read_bytes()).hexdigest(),
        source_zip_sha256=recipe['source_zip_sha256'],candidates=len(report['candidates']),
        episodes=sum(len(c['episodes']) for c in report['candidates'])))

candidates=reports['confirmation']['candidates']
colors=['#637086','#d18a29','#146b52']
labels=['Original host teacher','Intermediate 6,5,30,3','Selected 1,2,40,2']
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                     'axes.grid':True,'grid.alpha':.18,'figure.facecolor':'#fbfcfa'})
fig,axes=plt.subplots(3,2,figsize=(13,10),layout='constrained')
for candidate,color,label in zip(candidates,colors,labels):
    for episode in candidate['episodes']:
        rows=[json.loads(line) for line in (BASE/'confirmation'/episode['trajectory_path']).read_text().splitlines()]
        t=np.array([r['t_s'] for r in rows]); x=np.array([r['x'] for r in rows]); raw=np.array([r['raw'] for r in rows]); th=np.array([r['theta'] for r in rows])
        axes[0,0].plot(t,x*1000,color=color,alpha=.3,lw=.8)
        mask=t>=20
        axes[0,1].plot(t[mask],x[mask]*1000,color=color,alpha=.6,lw=.9)
        if episode['seed']==42000:
            axes[1,0].plot(t,th,color=color,label=label,lw=1)
            axes[1,1].plot(t,raw,color=color,label=label,lw=.8,alpha=.9)
    axes[2,0].scatter([labels.index(label)]*len(candidate['episodes']),
        [e['last5s']['x_rms_m']*1000 for e in candidate['episodes']],color=color,s=28)
    axes[2,1].scatter([labels.index(label)]*len(candidate['episodes']),
        [e['all']['raw_action_delta_rms'] for e in candidate['episodes']],color=color,s=28)
for ax in axes[0]:
    ax.set_ylabel('Cart position (mm)');ax.set_xlabel('Time (s)');ax.axhline(120,color='#aa4538',lw=.8,ls='--');ax.axhline(-120,color='#aa4538',lw=.8,ls='--')
axes[0,0].set_title('All six 25-second development trajectories')
axes[0,1].set_title('Final five seconds: selected teacher settles')
axes[1,0].set(title='Pole angle, example seed 42000',xlabel='Time (s)',ylabel='Angle (rad)')
axes[1,1].set(title='Raw acceleration, example seed 42000',xlabel='Time (s)',ylabel='Raw acceleration (m/s²)')
axes[1,0].legend(fontsize=8)
axes[2,0].set(title='Final 5-second cart RMS, each seed',ylabel='Cart RMS (mm)')
axes[2,1].set(title='Raw action change RMS, each seed',ylabel='Δ raw acceleration RMS (m/s²)')
for ax in axes[2]:
    ax.set_xticks(range(3),['Original','Intermediate','Selected'])
fig.suptitle('Observed-state balance teacher · nominal encoder model · development seeds 42000–42005',fontsize=14)
fig.savefig(BASE/'comparison.png',dpi=160)
plt.close(fig)

selected=candidates[-1]
recipe=json.loads((BASE/'confirmation/recipe.json').read_text())
config=recipe['experiment']['simulation_config'];L=config['effective_length_m'];d=recipe['linearization']['zero_velocity_damping_rate']
A=np.array([[0,1,0,0],[0,0,0,0],[0,0,0,1],[0,0,9.81/L,-d]])
B=np.array([[0],[1],[0],[-1/L]])
eigenvalues={}
for c in candidates:
    K=np.array([c['gains'][name] for name in ('position_gain','velocity_gain','theta_gain','omega_gain')])[None,:]
    eigenvalues[c['name']]=[[float(v.real),float(v.imag)] for v in np.linalg.eigvals(A+B@K)]
verification_dict=dict(verified=True,phases=verification,linearized_eigenvalues_real_imag=eigenvalues,
    source_script_sha256=recipe['source_manifest']['examples/balance_teacher_search.py'],
    report_script_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
    comparison_png_sha256=sha256((BASE/'comparison.png').read_bytes()).hexdigest())
(BASE/'verification.json').write_text(json.dumps(verification_dict,indent=2)+'\n')
artifact=json.loads((BASE/'confirmation/teacher-gains.json').read_text())
artifact.update(confirmation_development_seeds=recipe['seeds'],confirmation_seconds=25,
    report_path='confirmation/report.json',recipe_path='confirmation/recipe.json',
    source_zip_path='confirmation/source.zip',source_zip_sha256=recipe['source_zip_sha256'],
    limitations=['Nominal balance-only development evidence; no hanging starts or randomization.',
                 'These six seeds were inspected; 45000+ remain unused for separate evaluation.',
                 'Raw action change RMS increases despite lower cart oscillation and acceleration RMS.',
                 'No hardware acceptance or production actor export.'])
(BASE/'teacher-gains.json').write_text(json.dumps(artifact,indent=2)+'\n')

lines=['# Observed-state nominal balance teacher search','',
'**Selected law:** `raw = clip(1*x + 2*v + 40*theta + 2*omega, -25, 25)` in m/s²; wrap observed theta with `atan2(sin(theta), cos(theta))`. The inputs come only from the returned Gym observation. `raw_acceleration` in `examples/balance_teacher_search.py` implements the callable law. Simulator truth is accessed only after acting, for metrics.',
'',
'The selected teacher holds all six 25-second development episodes with every step meeting `|x|<.12 m`, `|theta|<.15 rad`, and `|omega|<1 rad/s`. The source and all trajectories are hash pinned. This is local nominal balance evidence only.',
'',
'| Controller | Final 5s holds | Min balanced fraction | Peak |x| (mm) | Worst margin (mm) | Mean cart RMS (mm) | Worst final5s cart swing (mm) | Mean raw RMS | Mean raw Δ RMS | Faults |',
'|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
# Vertical bars in math labels are escaped for valid Markdown.
lines[-2]=lines[-2].replace('Peak |x|','Peak abs(x)')
for c,label in zip(candidates,labels):
    s=c['summary']
    lines.append(f"| {label} | {s['hold_successes']}/6 | {s['min_balanced_fraction']:.4f} | {s['max_abs_x_m']*1000:.2f} | {s['worst_centering_margin_m']*1000:.2f} | {s['mean_x_rms_m']*1000:.2f} | {s['worst_last5s_x_peak_to_peak_m']*1000:.2f} | {s['mean_raw_action_rms']:.4f} | {s['mean_raw_action_delta_rms']:.4f} | {s['faults']} |")
lines += ['', 'All candidates retain the original 100 Hz decisions, 1 ms physics, encoder noise/quantization and causal rate observer, 3 ms telemetry delay, 1 ms command delay, one motion governor with jerk 150 m/s³, and raw acceleration bounds ±25 m/s². No dynamics randomization is applied. No hardware or Colab connection is made.',
'', '## Selection and model reasoning', '',
'1. Fifteen candidates, including the exact host teacher, its memoryless linear equivalent, hand gains and five discrete LQR designs, were screened on seeds 42000/42001 for 15 seconds each. Host and linear-prior trajectories agreed. The intermediate `(6,5,30,3)` teacher reduced the cart cycle but did not remove it. Aggressive ideal LQR designs failed in the complete observed/governed simulation.',
'2. Ten additional four-gain hypotheses targeted local stability of the smooth hinge friction. The zero-rate friction derivative is included in the approximate acceleration-input linearization. The original and intermediate gains have unstable complex eigenvalues in this local approximation; `(1,2,40,2)` has a stable slow pair near `-0.3324 ± 0.7379i`. Finite-velocity friction, rate-estimator lag and the governor are nonlinear or omitted from synthesis, so the full environment remains the empirical criterion.',
'3. The original host, intermediate `(6,5,30,3)` and selected `(1,2,40,2)` teachers were each evaluated for 25 seconds on seeds 42000–42005. These are development/regression cases after inspection. Seeds 45000+ were never used.',
'', 'The selected law substantially reduces cart motion and total raw acceleration RMS. Its raw action step-to-step RMS is higher because the larger raw angle gain amplifies encoder quantization/noise; the action-change tradeoff is retained in the table and plots. It remains subject to the unchanged governor.',
'', '## Artifacts', '',
'- `teacher-gains.json`: selected formula, exact gains, development status and provenance links.',
'- `settling-gains-flat.json`: flat four-gain dictionary for the parent learning harness.',
'- `screen/`, `refine/`, `confirmation/`: immutable recipes, complete per-candidate episode metrics, JSONL trajectories, source ZIPs and selected-gain artifacts.',
'- `comparison.png`: complete cart trajectories, final-five-second motion, representative pole/raw action traces, and per-seed RMS metrics.',
'- `verification.json`: checked recipe/source/trajectory digests and approximate closed-loop eigenvalues.',
'', '## Reproduction', '',
'From the same repository and installed dependencies (versions pinned in each recipe), run with a new output directory. The script sets the numerical thread environment and PyTorch threads to one.',
'', '```sh',
'PYTHONDONTWRITEBYTECODE=1 .venv/bin/python examples/balance_teacher_search.py --output runs/NEW-screen --seconds 15 --seeds 42000 42001',
'PYTHONDONTWRITEBYTECODE=1 .venv/bin/python examples/balance_teacher_search.py --output runs/NEW-refine --seconds 15 --seeds 42000 42001 --candidates runs/local-balance-teacher-20261018/refine-candidates.json',
'PYTHONDONTWRITEBYTECODE=1 .venv/bin/python examples/balance_teacher_search.py --output runs/NEW-confirmation --seconds 25 --seeds 42000 42001 42002 42003 42004 42005 --candidates runs/local-balance-teacher-20261018/confirmation-candidates.json',
'```', '',
f"Source commit at run start: `{recipe['source_commit']}`. Search script SHA-256: `{verification_dict['source_script_sha256']}`. Confirmation source ZIP SHA-256: `{recipe['source_zip_sha256']}`. Source archives, not the commit alone, capture the exact uncommitted runtime state.",
'', 'No stochastic optimization, neural training, swing-up assessment, dynamics/timing variation, invalid-sensor stress, physical qualification, production parameter change, or export is claimed here.']
(BASE/'README.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(verified=verification,selected=selected['summary'],teacher_sha256=sha256((BASE/'teacher-gains.json').read_bytes()).hexdigest()),indent=2))
