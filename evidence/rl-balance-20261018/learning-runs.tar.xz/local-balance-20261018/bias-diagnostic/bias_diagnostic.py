#!/usr/bin/env python3
"""Development-only counterfactual: center final PPO actors without retraining."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import shutil
import time
import numpy as np
import torch
from stable_baselines3 import PPO
from cartpole_sdk.learning.balance_experiment import evaluate_balance, source_identity


def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    runs = []
    pins = source_identity()
    for seed in (3, 17, 29):
        run = args.root / f'teacher-v1-seed{seed}'
        report = json.loads((run / 'report.json').read_text())
        recipe = json.loads((run / 'recipe.json').read_text())
        selected = next(e for e in report['evaluations'] if e['steps'] == 20480)
        cp = run / selected['checkpoint']
        if pins != recipe['provenance']:
            raise ValueError('source/dependency differs from training')
        if digest(cp) != selected['checkpoint_sha256']:
            raise ValueError('checkpoint hash mismatch')
        runs.append(dict(optimizer_seed=seed, run=str(run.resolve()),
            recipe_sha256=digest(run/'recipe.json'), source_zip_sha256=digest(run/'source.zip'),
            report_sha256=digest(run/'report.json'), checkpoint=str(cp.resolve()),
            checkpoint_sha256=digest(cp), checkpoint_steps=20480,
            evaluation_seeds=report['evaluation_seeds'],
            original_summary=selected['by_start'], initial_summary=report['evaluations'][0]['by_start']))
    args.output.mkdir(parents=True, exist_ok=False)
    script = args.output / 'bias_diagnostic.py'
    shutil.copyfile(__file__, script)
    recipe = dict(schema='cartpole-equilibrium-bias-diagnostic-v1',
        role='Counterfactual on previously inspected development seeds; not held-out qualification.',
        transformation='Subtract policy Gaussian mean at fixed reference from action_net.bias once, then ordinary deterministic PPO.predict.',
        reference_observation=dict(state=[0.,0.,0.,1.,0.,0.,0.], valid=[1]*7, age_s=[0.]*7),
        duration_seconds=10., starts=['upright'], optimizer_seeds=[3,17,29],
        checkpoint_steps=20480, training_updates=0, simulation_only=True,
        hardware_accepted=False, deployable=False, no_teacher_rollout=True,
        policy_checkpoint_written=False, source_provenance=pins,
        script_sha256=digest(script), runs=runs)
    write(args.output/'recipe.json', recipe)
    torch.set_num_threads(1)
    outcomes=[]
    began=time.monotonic()
    for item in runs:
        run=Path(item['run'])
        training_recipe=json.loads((run/'recipe.json').read_text())
        model=PPO.load(item['checkpoint'],device='cpu')
        obs={k:torch.tensor([v],dtype=torch.float32) for k,v in recipe['reference_observation'].items()}
        with torch.no_grad():
            normalized_bias=float(model.policy.get_distribution(obs).distribution.mean.item())
            model.policy.action_net.bias.sub_(normalized_bias)
            residual=float(model.policy.get_distribution(obs).distribution.mean.item())
        evaluation=evaluate_balance(model,training_recipe['experiment'],seeds=item['evaluation_seeds'],seconds=10.,traces=True)
        evaluation.update(optimizer_seed=item['optimizer_seed'],checkpoint_sha256=item['checkpoint_sha256'],
            original_summary=item['original_summary'],initial_summary=item['initial_summary'],
            subtracted_normalized_mean=normalized_bias,subtracted_raw_bias_m_s2=normalized_bias*25,
            corrected_reference_raw_action_m_s2=residual*25,
            role=recipe['role'],training_updates=0)
        name=f'seed-{item["optimizer_seed"]}.json'
        write(args.output/name,evaluation)
        outcomes.append(dict(optimizer_seed=item['optimizer_seed'],evaluation_file=name,
            evaluation_sha256=digest(args.output/name),subtracted_raw_bias_m_s2=normalized_bias*25,
            original_summary=item['original_summary'],corrected_summary=evaluation['by_start']))
        print(json.dumps(outcomes[-1]),flush=True)
    if source_identity()!=pins:
        raise ValueError('source/dependency changed during diagnostic')
    write(args.output/'report.json',dict(schema=recipe['schema'],completed=True,
        recipe_sha256=digest(args.output/'recipe.json'),outcomes=outcomes,
        role=recipe['role'],wall_seconds=time.monotonic()-began,hardware_accepted=False,deployable=False))


if __name__=='__main__':
    main()
