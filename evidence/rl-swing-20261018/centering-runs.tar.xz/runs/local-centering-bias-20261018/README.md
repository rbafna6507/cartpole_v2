# Observed-state centering and angle-bias diagnostic

Development-only simulation screen, 2026-10-18. No hardware, neural training,
SDK export or core simulator change. The unchanged curriculum-seed17 experiment
supplies the plant, sensing and governor; the controller is a separate linear law
using only observed x, velocity, angle and angular rate.

```sh
.venv/bin/python examples/centering_bias_screen.py \
  --run runs/local-swing-20261018/curriculum-seed17 \
  --output runs/local-centering-bias-20261018-repeat --seconds 25
```

All 36 episodes completed 25 seconds without simulator faults: six fixed laws,
upright poses 58000/58001, and nominal / -1 degree / +1 degree actor-angle bias.
Bias does not alter physical truth, encoder zero, rate, validity or the governor.
The final-hold criterion checks every successive 100 Hz post-step sample in the
final five seconds: |theta|<0.15 rad, |omega|<1 rad/s and |x|<0.12 m.

| Gains (x, v, theta, omega) | Nominal holds | -1 degree holds | +1 degree holds | Worst abs(x), m |
| --- | --- | --- | --- | --- |
| (1, 2, 40, 2) | 2/2 | 0/2 | 0/2 | 0.293963 |
| (4, 4, 40, 2) | 2/2 | 0/2 | 0/2 | 0.279312 |
| (8, 4, 40, 2) | 0/2 | 0/2 | 0/2 | 0.243157 |
| (8, 6, 40, 3) | 2/2 | 0/2 | 0/2 | 0.162793 |
| (12, 4, 40, 2) | 0/2 | 0/2 | 0/2 | 0.220058 |
| (12, 6, 40, 3) | 2/2 | 0/2 | 0/2 | 0.149197 |

No law passed all six initial episodes, so none was selected. The predeclared
confirmation seeds 58100..58103 were not evaluated; `confirmation_pass=false`
therefore means no qualifying candidate, not a failed confirmation rollout.

The strongest-centering law reduces the biased mean cart position to about
±0.06 m, close to the simple static prediction ±40*(pi/180)/12 = ±0.0582 m.
It still oscillates far enough to fail the cart-position condition: final-window
biased cart extremes reach -0.145/+0.149 m, while true angle remains below
0.052 rad and true angular rate below 0.211 rad/s. Its biased final-window
balanced fraction is 0.728–0.780. Stronger centering reduces the static offset
but these tested gains do not establish robust balance.

`recipe.json` fixes inputs, six laws, selection rule, seeds and source hashes.
`source.py` is the executed standalone script. `report.json` retains all episode
metrics and trace hashes; `traces/` contains 90,000 decisions across 36 gzip JSONL
files. After completion, every trace hash, row count, recipe hash and archived
script hash was verified. The script also checked runtime/source hashes before
and after the run. Two minimal test-first checks passed for observed-law bias,
clipping/input immutability, and the all-episode selection requirement.

These are deliberately chosen engineering stresses and inspected development
poses, not measured uncertainty or a hardware success probability.
